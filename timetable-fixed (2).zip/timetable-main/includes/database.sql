DROP DATABASE IF EXISTS timetable_db;
CREATE DATABASE timetable_db;
USE timetable_db;

CREATE TABLE lecturers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100)
) ENGINE=InnoDB;

CREATE TABLE cohorts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  size INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE halls (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  capacity INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL,
  title VARCHAR(100) NOT NULL,
  lecturer_id INT NOT NULL,
  cohort_id INT NOT NULL,
  sessions_per_week INT DEFAULT 1,
  duration_hours INT DEFAULT 1,
  FOREIGN KEY (lecturer_id) REFERENCES lecturers(id),
  FOREIGN KEY (cohort_id) REFERENCES cohorts(id)
) ENGINE=InnoDB;

CREATE TABLE timetable (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  hall_id INT NOT NULL,
  day ENUM('Mon','Tue','Wed','Thu','Fri') NOT NULL,
  start_hour INT NOT NULL,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (hall_id) REFERENCES halls(id)
) ENGINE=InnoDB;

INSERT INTO halls (name, capacity) VALUES ('Hall A', 80), ('Hall B', 40);
INSERT INTO lecturers (name) VALUES ('Dr. Adeyemi'), ('Prof. Bello'), ('Dr. Musa');
INSERT INTO cohorts (name, size) VALUES ('Year 1', 75), ('Year 2', 55), ('Year 3', 35);
INSERT INTO courses (code, title, lecturer_id, cohort_id, sessions_per_week, duration_hours) VALUES
  ('CS101', 'Intro to Programming', 1, 1, 2, 1),
  ('CS102', 'Discrete Math', 2, 1, 1, 1),
  ('CS201', 'Data Structures', 1, 2, 2, 1),
  ('CS202', 'Computer Architecture', 3, 2, 1, 1),
  ('CS301', 'Databases', 2, 3, 2, 1),
  ('CS302', 'Operating Systems', 3, 3, 1, 1);
