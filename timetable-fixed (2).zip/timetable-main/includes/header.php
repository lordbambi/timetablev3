<?php
include_once __DIR__ . '/../config/db.php';
$page = basename($_SERVER['SCRIPT_NAME']);
$nav = [
  'index.php'     => 'Dashboard',
  'courses.php'   => 'Courses',
  'lecturers.php' => 'Lecturers',
  'halls.php'     => 'Halls',
  'cohorts.php'   => 'Cohorts',
  'generate.php'  => 'Generate',
  'view.php'      => 'View timetable',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lecture Timetable Management System</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&family=Source+Sans+3:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="shell">
  <aside class="side">
    <div class="brand">
      <span class="brand-name">Lecture Timetable</span>
      <span class="brand-sub">Management System</span>
    </div>
    <nav>
      <?php foreach ($nav as $file => $label): ?>
        <a href="<?= $file ?>" class="<?= $page === $file ? 'on' : '' ?>"><?= $label ?></a>
      <?php endforeach; ?>
    </nav>
  </aside>
  <main>
