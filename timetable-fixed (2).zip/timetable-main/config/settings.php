<?php
// Timetable settings - edit here only (used by generate.php and view.php)
$TT_DAYS       = ['Mon', 'Tue', 'Wed'];   // any of: Mon, Tue, Wed, Thu, Fri
$TT_FIRST_HOUR = 8;                        // first lecture starts at 08:00
$TT_LAST_HOUR  = 11;                       // lectures must end by 11:00
