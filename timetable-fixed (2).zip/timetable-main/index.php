<?php
include 'includes/header.php';

function count_rows($conn, $table) {
    return (int)$conn->query("SELECT COUNT(*) AS c FROM $table")->fetch_assoc()['c'];
}
$courses   = count_rows($conn, 'courses');
$lecturers = count_rows($conn, 'lecturers');
$halls     = count_rows($conn, 'halls');
$lectures  = count_rows($conn, 'timetable');
?>
<h1>Dashboard</h1>

<div class="stats">
    <div><strong><?= $courses ?></strong><span>Courses</span></div>
    <div><strong><?= $lecturers ?></strong><span>Lecturers</span></div>
    <div><strong><?= $halls ?></strong><span>Lecture halls</span></div>
    <div><strong><?= $lectures ?></strong><span>Scheduled lectures</span></div>
</div>

<section class="next">
  <?php if (!$courses || !$halls): ?>
    <h2>Add your courses and halls first</h2>
    <p>The timetable is built from your courses, lecturers, cohorts and halls. Add them, then come back here.</p>
    <a class="btn" href="courses.php">Go to courses</a>
  <?php elseif (!$lectures): ?>
    <h2>Your data is ready</h2>
    <p>Generate a clash-free timetable for <?= $courses ?> courses in one click.</p>
    <a class="btn" href="generate.php">Generate timetable</a>
  <?php else: ?>
    <h2>Your timetable is ready</h2>
    <p><?= $lectures ?> lectures are scheduled with no clashes. Filter by lecturer, cohort or hall, or print it.</p>
    <a class="btn" href="view.php">View timetable</a>
    <a class="btn ghost" href="generate.php">Regenerate</a>
  <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>
